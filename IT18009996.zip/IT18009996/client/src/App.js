import React from 'react';

function App() {
  return (
    <div className="App">
      <p>INTHIRAJITH _ CLOUD COMPUTING ASSIGNMENT_CLIENT </p>
    </div>
  );
}

export default App;
